purkinje17.f
Model of a cerebellar Purkinje cell.  This is an extension and refinement of
an earlier model by Miyasho et al., made more schematic in the architecture, 
and with the addition of an axon.

purkinje_bignet21.f
Model of a network of 1000 Purkinje cells, with gap junctions between proximal 
axons.  It runs on a Linux cluster with mpi, either on 40 or 50 processors.
