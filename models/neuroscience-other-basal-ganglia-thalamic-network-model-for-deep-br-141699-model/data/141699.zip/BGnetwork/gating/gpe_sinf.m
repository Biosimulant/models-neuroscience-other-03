function sinf=gpe_sinf(V)
sinf=1./(1+exp(-(V+35)./2));
return