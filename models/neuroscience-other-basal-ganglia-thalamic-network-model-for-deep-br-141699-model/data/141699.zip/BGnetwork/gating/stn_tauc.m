function tau=stn_tauc(V)
tau=1+10./(1+exp((V+80)/26));
return