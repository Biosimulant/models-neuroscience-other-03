function h=Hinf(V)
h=1./(1+exp(-(V+57)./2));
return