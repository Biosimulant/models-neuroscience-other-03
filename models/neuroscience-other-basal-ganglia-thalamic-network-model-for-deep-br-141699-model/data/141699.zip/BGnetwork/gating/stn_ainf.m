function ainf=stn_ainf(V)
ainf=1./(1+exp(-(V+63)./7.8));
return