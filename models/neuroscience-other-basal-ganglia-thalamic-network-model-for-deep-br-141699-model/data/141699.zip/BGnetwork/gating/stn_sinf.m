function sinf=stn_sinf(V)
sinf=1./(1+exp(-(V+39)./8));
return