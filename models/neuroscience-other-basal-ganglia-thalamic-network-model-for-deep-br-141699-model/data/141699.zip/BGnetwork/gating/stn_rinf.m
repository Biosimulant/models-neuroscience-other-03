function rinf=stn_rinf(V)
rinf=1./(1+exp((V+67)./2));
return