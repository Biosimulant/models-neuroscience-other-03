package stimulusdelayreward;
import lnsc.page.*;

/** There are no necessary actions here, so here is a NoAction.
 *
 * @author Francois Rivest
 * @version 1.0
 */

public class NoAction extends AbstractAction {

    /*********************************************************************/
    //Constructors

    public NoAction() {}

}