// basinc - h-file with helpful include operations and File_error s/p
// Kazanovich April 98

#include	<stdlib.h>
#include	<conio.h>
#include	<iostream.h>
#include	<fstream.h>
#include	<strstrea.h>
#include	<stdio.h>
#include	<math.h>
#include	<time.h>
#include	<iomanip.h>

#define	ESC 27

// Variable to keep the device content
extern CDC *myDC;

