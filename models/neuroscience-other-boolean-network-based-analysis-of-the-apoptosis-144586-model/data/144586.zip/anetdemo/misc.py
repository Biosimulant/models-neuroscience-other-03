# $Id: misc.py,v 1.6 2011/07/30 19:50:26 billl Exp $
import sys

# p.ppr(5)
def pr(x):
 print(x)

# p.hp(p.numpy)
def hp(x):
 help(x)

# p.dr(p.numpy)
def dr(x):
 print(dir(x))





