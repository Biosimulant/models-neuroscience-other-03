python build_network.py
python run_network.py