rm exc_stim_spikes2.h5
python modulate_exc.py
python run_network.py
