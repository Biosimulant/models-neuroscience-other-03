python build_network.py
#python run_network.py 0.401 0.31
#python run_network.py 0.65 0.445
#python run_network.py 0.69 0.44
#python run_network.py 1 0.4
#python run_network.py 0.65 0.48
python run_network.py