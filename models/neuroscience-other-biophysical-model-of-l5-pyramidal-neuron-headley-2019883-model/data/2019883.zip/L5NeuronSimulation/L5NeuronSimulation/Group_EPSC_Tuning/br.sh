#python build_network.py 300
python build_network.py 300
#python run_network.py 0.24575 0.345 #REALLY GOOD
python run_network.py 0.3 0.345 #Ben's settings
#python run_network.py 0.26252 0.345
#python run_network.py 3 0
#python run_network.py 0.291 0.564
#python run_network.py 0.45 0.35
#python build_all_segs.py
#python run_network.py 0.8 0
#python run_network.py 0.4 0
#python run_network.py 0.45 0.4
#python run_network.py 0.77 0.918
#python run_network.py 0.95 1.3 #WHAT I WAS GONNA USE
#python run_network.py -0.702 0.8752
#python run_network.py 0.65 0.445
#python run_network.py 0.69 0.44
#python run_network.py 1 0.4
#python run_network.py 0.65 0.48