#python new_syn_build.py 2
python build_network.py 3
python run_network.py