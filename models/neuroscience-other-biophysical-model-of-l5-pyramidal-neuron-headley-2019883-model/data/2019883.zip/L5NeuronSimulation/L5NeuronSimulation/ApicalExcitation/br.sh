python build_network.py 50
python run_network.py 0.1 0