python build_network.py Perisomatic 256
#python run_network.py 27.79 0.21
python run_network.py 44.75 0
# python show_results.py