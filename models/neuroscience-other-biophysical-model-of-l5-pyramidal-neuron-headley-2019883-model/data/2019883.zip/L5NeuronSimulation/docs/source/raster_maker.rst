raster_maker.py
================

.. image:: images/RasterFigure.png
  :alt: Functional Group Raster Figure

.. automodule:: L5NeuronSimulation.raster_maker
   :members:
   :private-members: