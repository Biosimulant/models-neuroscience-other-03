clustering.py
================

.. image:: images/ClusteringFigure.png
  :alt: Clustering Figure

.. automodule:: L5NeuronSimulation.clustering
   :members:
   :private-members: