/*
 * Test1.java
 *
 * Created on December 20, 2000, 10:05 AM
 */

package pharynx;
import java.io.*;

/**
 *
 * @author  leon
 * @version 
 */
public class Test1 extends java.lang.Object {

    /** Creates new Test1 */
    public Test1() {
    }

    /**
    * @param args the command line arguments
    */
    public static void main (String args[]) {
        System.out.println("Working.");
    }

}
