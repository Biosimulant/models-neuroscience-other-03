function [I,T] = ithr
%ITHR Current-threshold relationship
%