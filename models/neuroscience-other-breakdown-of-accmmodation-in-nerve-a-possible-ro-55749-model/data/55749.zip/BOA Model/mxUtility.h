#ifndef MXUTILITY_V10
#define MXUTILITY_V10

int isScalar(const mxArray *prhs);
long isVector(const mxArray *prhs);
long idx(long i,long j,long M);

#endif