function testac_f2(pNap,TAU,E)
%TESTAC Test accommodation
%   testac(pNap,TAU,E)

M = defPatch_f1([1 pNap 1 1]); 