function [M] = defModel()
%defModel Default model
%   [M] = defModel()
M = model_Nap([2.5 -20 0.5]);