# -*- coding: utf-8 -*-
"""
@author: chris
"""

# time uses SI!!!
ms = 1e-3
s = 1
sec = 1

# rest not (yet)
nA = 1
mV = 1
Hz = 1
uS = 1
nS = 1e-3
MOhm = 1
uF = 1
pF = 1e-6