#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double *ifun2(double *r, int *N, int T, int *C, double *tau, double *kappa, double *ih, double *I); 
