#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double *ifun(double *r, int N, int T, double Pr, double tau, double kappa, double *ih, double *I); //const unsigned long seed
