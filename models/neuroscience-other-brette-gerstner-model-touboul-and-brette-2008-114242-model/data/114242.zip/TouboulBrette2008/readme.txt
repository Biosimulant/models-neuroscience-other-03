This is the readme for the model associated with the paper:

Touboul J, Brette R (2008) Dynamics and bifurcations of the adaptive
exponential integrate-and-fire model Biol Cyber 99(4-5):319-34

This is the Brian code that the authors used and was contributed by R Brette.

Some notes on the included files:

Diagram.py   Figs 3 and 4
spikes.py    Figs 5 and 6
chaos.py     Fig 7
behaviors.py Response of Brette-Gerstner model with different parameter values
