This the readme for the model files associated with the paper:

Choi H, Zhang L, Cembrowski M, Sabottke C, Markowitz A, Butts D, Kath
W, Singer J, Riecke H (2014) Intrinsic Bursting of AII Amacrine Cells
Underlies Oscillations in the rd1 Mouse Retina. J Neurophysiol

These files were contributed by H Riecke.

Type A2ONCB on the matlab command line to run the basic model.
Depending on the variable plotswitch it generates Fig.5B or Fig.14 of
that paper.  To generate generate Fig.5A type A2ONCB_Fig5a. To
generate Fig.13 type A2ONC_FHN.
