This is the readme for the model associated with the paper:

Ferguson KA, Njap F, Nicola W, Skinner FK, Campbell SA (2015)
Examining the limits of cellular adaptation bursting mechanisms in
biologically-based excitatory networks of the hippocampus. J Comput
Neurosci

More information will be made available soon for this "brian" model.
