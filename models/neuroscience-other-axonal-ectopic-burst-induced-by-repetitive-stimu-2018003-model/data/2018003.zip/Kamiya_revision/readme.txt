﻿This is the readme for the simulation showing the activity-dependent generation of afterdischarge at slightly depolarized conditions at -70mV than the resting -80mV. 
We tested 50 Hz train stimuli for 50 times, 20 Hz train stimuli for 60 times, and 100 Hz for 50 times. 
The responses at -70 mv or -60 mV (depolarized) and -80 mv (resting condition) of membrane potentials at distal (the 10th bouton and the 10th-11th axons), middle (the 6th bouton and the 6th-7th axons), and proximal (the 2nd bouton and the 2nd-3rd axons) portions were compared. 
Upon depolarization of middle portions, bi-directional propagation was shown by calculating the responses at the soma, the 6th, and the 10th boutons. 
The mixed inactivating (90 %) and non-inactivating (10 %) K conductance were also tested for the generation of afterdischarge.

To run the simulations, follow these steps:
Compile the mod files using nrnivmodl under Mac OS X and Linux, or mknrndll under Windows.
Run mosinit.hoc in NEURON.
Click the radiobuttons in the panel "Demo" and click "Init & Run" in the "RunControl" panel to run simulations.

Questions about this model should be directed to kamiya@med.hokudai.ac.jp.


