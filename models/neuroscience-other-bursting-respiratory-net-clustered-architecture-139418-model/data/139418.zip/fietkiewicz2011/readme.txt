Author: Chris Fietkiewicz, Ph.D., Case Western Reserve University

Contact: chris.fietkiewicz at case.edu

Instructions: Requires NEURON
(http://www.neuron.yale.edu/neuron). Compile mod files before running
simulations. Run either figure11.hoc or figure13.hoc to recreate
raster plots similar to Figure 11 or Figure 13, respectively, from the
paper. See source code and paper for additional documentation.

20120113 updates from Fietkiewicz for Fig 11, 13 and update of euler
method to derivimplicit for capump.mod as per
http://www.neuron.yale.edu/phpbb/viewtopic.php?f=28&t=592
