Code of the eupnea-sigh model for Borrus et al., 2024

---

`do_make_data.m` is the leader script that RUNS `tabakrinzelcalcium.m` in MATLAB
so, `run do_make_data.m` and not the other `.m` file

---

`v4_EupneaSigh.ode` is the same code written for the application XPPAUT