%% Tabak-Rinzel-like model
%% do_make_data.m example

clc; clear; close all;

% Example calcium oscillation open cell model
[param, out] = tabakrinzelcalcium('trans',3000,'total',3300);