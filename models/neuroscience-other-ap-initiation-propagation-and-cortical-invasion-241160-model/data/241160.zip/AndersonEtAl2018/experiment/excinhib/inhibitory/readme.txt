tauf=62*ptMultiple;
taud=144*ptMultiple;
U=.32;    %between .1-.95 for excitatory synapse, naturally found