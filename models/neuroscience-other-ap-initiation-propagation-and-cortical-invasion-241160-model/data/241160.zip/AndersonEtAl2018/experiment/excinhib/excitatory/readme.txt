tauf=17*ptMultiple;
taud=671*ptMultiple;
U=.5;    %between .1-.95 for excitatory synapse, naturally found