The 3 dimensional structure of the L5 pyramidal cell axon arbor is from:

Binzegger T, Douglas RJ, Martin KA. 2005. Axons in the cat visual cortex are topologically self-similar. Cereb Cortex. 15(2):152-65.