//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BPDBrain.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BPDBRAIN_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_VMPFC_DIALOG                129
#define IDD_BA_DIALOG                   130
#define IDD_ICM1_DIALOG                 131
#define IDD_ICM2_DIALOG                 132
#define IDD_CEA_DIALOG                  133
#define IDD_VLPAG_DIALOG                134
#define IDD_DLPAG_DIALOG                135
#define IDD_INTEGRATE_DIALOG            136
#define IDC_VMPFC_BUTTON                1000
#define IDC_BA_BUTTON                   1001
#define IDC_ICM1_BUTTON                 1002
#define IDC_ICM2_BUTTON                 1003
#define IDC_CEA_BUTTON                  1004
#define IDC_VLPAG_BUTTON                1005
#define IDC_DLPAG_BUTTON                1006
#define IDC_INTEGRATE_BUTTON            1007
#define IDC_ERASE_BUTTON                1008
#define IDC_QUIT_BUTTON                 1009
#define IDC_A_VMPFC_EDIT                1011
#define IDC_B_VMPFC_EDIT                1012
#define IDC_C_VMPFC_EDIT                1013
#define IDC_I_VMPFC_EDIT                1014
#define IDC_Z_VMPFC_O_EDIT              1015
#define IDC_A_BA_EDIT                   1016
#define IDC_B_BA_EDIT                   1017
#define IDC_C_BA_EDIT                   1018
#define IDC_I_BA_EDIT                   1019
#define IDC_A_ICM1_EDIT                 1020
#define IDC_B_ICM1_EDIT                 1021
#define IDC_C_ICM1_EDIT                 1022
#define IDC_A_ICM2_EDIT                 1023
#define IDC_B_ICM2_EDIT                 1024
#define IDC_ILA_EDIT                    1025
#define IDC_A_CEA_EDIT                  1026
#define IDC_B_CEA_EDIT                  1027
#define IDC_C_CEA_EDIT                  1028
#define IDC_A_VLPAG_EDIT                1029
#define IDC_B_VLPAG_EDIT                1030
#define IDC_C_VLPAG_EDIT                1031
#define IDC_IPAGI_EDIT                  1032
#define IDC_A_DLPAG_EDIT                1033
#define IDC_B_DLPAG_EDIT                1034
#define IDC_C_DLPAG_EDIT                1035
#define IDC_DELTAT_EDIT                 1036
#define IDC_NUMSTEPS_EDIT               1037
#define IDC_PRINT_BUTTON                1038
#define IDC_NDELAY_EDIT                 1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
