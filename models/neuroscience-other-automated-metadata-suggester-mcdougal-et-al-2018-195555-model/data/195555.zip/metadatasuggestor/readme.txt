This is the code for the methods associated with the article

McDougal RA, Dalal I, Morse TM, Shepherd GM (2018) Automated metadata suggestion
during repository submission, Neuroinfomatics.
https://doi.org/10.1007/s12021-018-9403-z

This python computer code was contributed by R McDougal.
Please see the enclosed license.

The code use regular expression patterns to identify candidate keywords for
models in ModelDB.

Please direct any questions to robert dot mcdougal at yale dot edu.
